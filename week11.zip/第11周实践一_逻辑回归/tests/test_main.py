"""实践一的 6 个基础测试。"""

import numpy as np
import pandas as pd
import pytest
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

from main import check, model, pred


def get_data():
    d = load_breast_cancer(as_frame=True)
    return d.frame[list(d.feature_names)], d.frame["target"]


def test_data_shape_and_classes():
    X, y = get_data()
    assert X.shape == (569, 30)
    assert y.value_counts().to_dict() == {1: 357, 0: 212}
    assert int(X.isna().sum().sum()) == 0


def test_empty_and_mismatch_are_rejected():
    with pytest.raises(ValueError):
        check(pd.DataFrame(), np.array([]))
    with pytest.raises(ValueError):
        check(pd.DataFrame(np.zeros((3, 2))), np.array([0, 1]))


def test_invalid_labels_are_rejected():
    with pytest.raises(ValueError):
        check(pd.DataFrame(np.zeros((3, 2))), np.array([0, 1, 2]))


def test_invalid_C_and_threshold_are_rejected():
    with pytest.raises(ValueError):
        model(C=0)
    X, y = get_data()
    m = model().fit(X, y)
    with pytest.raises(ValueError):
        pred(m, X, 1.5)


def test_split_and_predict():
    X, y = get_data()
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=.2, stratify=y, random_state=42)
    m = model().fit(Xtr, ytr)
    p, prob = pred(m, Xte)
    assert len(p) == len(Xte)
    assert np.all((prob >= 0) & (prob <= 1))
    assert set(np.unique(p)).issubset({0, 1})


def test_metrics_are_reasonable():
    X, y = get_data()
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=.2, stratify=y, random_state=42)
    m = model().fit(Xtr, ytr)
    p, _ = pred(m, Xte)
    assert 0 <= (p == yte.values).mean() <= 1
