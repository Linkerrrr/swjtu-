﻿# 第 11 周实践一：Breast Cancer 逻辑回归

一个精简的课程实践项目：只用一个 `main.py` 完成数据探索、Pipeline、逻辑回归、
网格搜索、测试集评估、二维决策边界和 C/阈值分析。所有随机过程固定
`random_state=42`。

## 数据集

唯一数据集：`sklearn.datasets.load_breast_cancer`。

- 569 个样本，30 个特征
- 恶性（0）212 条，良性（1）357 条
- 无缺失值

## 运行

```bash
python -m pip install -r requirements.txt
python main.py
pytest
```

`main.py` 会自动创建 `figures/` 和 `outputs/`。

## 代码步骤

| 步骤 | 做法 |
|---|---|
| 读取 | `load_breast_cancer(as_frame=True)`，检查数据和标签 |
| 探索 | 画类别分布和 5 个特征直方图 |
| 划分 | 8:2 分层划分，训练 455 / 测试 114 |
| Pipeline | `StandardScaler + LogisticRegression` |
| 网格搜索 | 5 折 CV，搜索 C、solver（penalty 固定 l2） |
| 评估 | 准确率、F1、混淆矩阵、分类报告、ROC/AUC |
| 二维图 | 用 mean radius、mean texture 画决策边界 |
| 调参图 | C 与 CV/测试准确率；阈值与准确率/F1 |

## 主要结果

- 最佳参数：`C=0.1, solver=lbfgs（penalty 默认 l2）`
- 5 折 CV 准确率：`0.9824`
- 测试集准确率：`0.9737`
- 测试集 F1：`0.9793`
- 测试集 AUC：`0.9957`

## 文件

```text
main.py                全部代码
README.md              本文件
requirements.txt       依赖
figures/               data.png / model.png / tuning.png / boundary2d.png
outputs/               coefficients.csv
tests/test_main.py     6 个基础测试
```
