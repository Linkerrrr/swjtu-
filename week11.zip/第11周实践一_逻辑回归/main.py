﻿# 第11周实践一：Breast Cancer 逻辑回归（桌面绝对路径版）  # 文件说明
import numpy as np  # 数值计算
import pandas as pd  # 表格处理
import matplotlib  # 绘图库
matplotlib.use("Agg")  # 不弹窗，直接保存图片
import matplotlib.pyplot as plt  # 绘图接口
from sklearn.datasets import load_breast_cancer  # 加载乳腺癌数据
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV, cross_val_score  # 划分、交叉验证、网格搜索
from sklearn.pipeline import Pipeline  # 组合标准化和模型
from sklearn.preprocessing import StandardScaler  # 特征标准化
from sklearn.linear_model import LogisticRegression  # 逻辑回归
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report, roc_curve, auc  # 评价指标
BASE = r"C:\Users\Lenovo\Desktop\第11周实践一_逻辑回归"; FIG = BASE + r"\figures"; OUT = BASE + r"\outputs"; SEED = 42  # 桌面路径、图片/输出目录、随机种子
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]; plt.rcParams["axes.unicode_minus"] = False  # 中文字体和负号
def check(X, y):  # 检查数据
    if len(X) == 0 or len(X) != len(y) or not set(np.unique(y)).issubset({0, 1}) or len(set(y)) < 2: raise ValueError("数据为空、维度不一致或标签不是 0/1")  # 抛出数据错误
def model(C=1.0, solver="lbfgs"):  # 建立模型
    if C <= 0: raise ValueError("C 必须大于 0")  # 检查正则化参数
    return Pipeline([("scaler", StandardScaler()), ("classifier", LogisticRegression(C=C, solver=solver, max_iter=5000, random_state=SEED))])  # 标准化 + 逻辑回归
def pred(m, X, t=0.5):  # 按阈值预测
    if not 0 <= t <= 1: raise ValueError("阈值必须在 0 到 1 之间")  # 检查阈值
    p = m.predict_proba(X)[:, 1]; return (p >= t).astype(int), p  # 概率转 0/1
data = load_breast_cancer(as_frame=True); df = data.frame; X, y = df[data.feature_names], df.target  # 转成 DataFrame
check(X, y); print("样本/特征/类别/缺失：", len(df), X.shape[1], y.value_counts().to_dict(), int(df.isna().sum().sum()))  # 输出数据概况
fig, axes = plt.subplots(2, 3, figsize=(11, 7)); axes = axes.ravel(); axes[0].bar(["恶性(0)", "良性(1)"], y.value_counts().sort_index(), color=["#c44e52", "#4c72b0"]); axes[0].set_title("类别分布")  # 画类别分布
for ax, name in zip(axes[1:], ["mean radius", "mean texture", "mean area", "mean smoothness", "mean concavity"]):  # 遍历五个特征
    for k, c in [(0, "#c44e52"), (1, "#4c72b0")]: ax.hist(df.loc[y == k, name], bins=20, alpha=.6, color=c)  # 按类别画直方图
    ax.set_title(name); ax.set_xlabel(name); ax.set_ylabel("频数")  # 设置标题和坐标轴
fig.tight_layout(); fig.savefig(FIG + r"\data.png"); plt.close(fig)  # 保存数据图
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, stratify=y, random_state=SEED); cv = StratifiedKFold(5, shuffle=True, random_state=SEED)  # 8:2 分层划分和 5 折
params = [{"classifier__C": [.001, .01, .1, 1, 10, 100, 1000], "classifier__solver": ["lbfgs", "liblinear"]}]  # 搜索 C 和 solver
grid = GridSearchCV(model(), params, scoring="accuracy", cv=cv, n_jobs=1).fit(Xtr, ytr); b = grid.best_params_; m = model(b["classifier__C"], b["classifier__solver"]).fit(Xtr, ytr)  # 网格搜索并重训
print("最佳参数/5折CV：", b, round(grid.best_score_, 4))  # 输出最佳参数和 CV
coef = pd.DataFrame({"特征": X.columns, "系数": m.named_steps["classifier"].coef_[0]}); coef["绝对值"] = coef["系数"].abs(); print(coef.sort_values("绝对值", ascending=False).head(5).to_string(index=False)); coef.to_csv(OUT + r"\coefficients.csv", index=False)  # 输出并保存系数
p = m.predict_proba(Xte)[:, 1]; q = (p >= .5).astype(int); cm = confusion_matrix(yte, q); fpr, tpr, _ = roc_curve(yte, p)  # 测试集概率、预测、混淆矩阵、ROC
print("测试集 准确率/F1/AUC：", round(accuracy_score(yte, q), 4), round(f1_score(yte, q), 4), round(auc(fpr, tpr), 4)); print(cm); print(classification_report(yte, q, target_names=["恶性(0)", "良性(1)"], digits=3))  # 输出评价结果
fig, axes = plt.subplots(1, 2, figsize=(10, 4)); axes[0].plot(fpr, tpr, color="#c44e52", label="AUC=%.4f" % auc(fpr, tpr)); axes[0].plot([0, 1], [0, 1], "--", color="gray"); axes[0].set_title("ROC 曲线"); axes[0].legend()  # 画 ROC
axes[1].imshow(cm, cmap="Blues"); axes[1].set_xticks([0, 1], ["预测恶性", "预测良性"]); axes[1].set_yticks([0, 1], ["真实恶性", "真实良性"]); axes[1].set_title("混淆矩阵（阈值 0.50）")  # 画混淆矩阵
fig.tight_layout(); fig.savefig(FIG + r"\model.png"); plt.close(fig)  # 保存评价图
ts = np.arange(.05, .96, .05); th = [[t, accuracy_score(yte, p >= t), f1_score(yte, p >= t)] for t in ts]; cs = np.logspace(-3, 3, 7); cvs = [cross_val_score(model(C), Xtr, ytr, cv=cv).mean() for C in cs]  # 阈值表和 C 的 CV
fig, axes = plt.subplots(1, 2, figsize=(11, 4)); axes[0].semilogx(cs, cvs, "o-"); axes[0].axvline(b["classifier__C"], color="gray", ls="--"); axes[0].set_xlabel("C"); axes[0].set_ylabel("5折CV准确率"); axes[0].set_title("C 的影响")  # 画 C 的影响
axes[1].plot(ts, [r[1] for r in th], "o-", label="准确率"); axes[1].plot(ts, [r[2] for r in th], "s-", label="F1"); axes[1].set_xlabel("阈值"); axes[1].set_title("阈值的影响"); axes[1].legend()  # 画阈值的影响
fig.tight_layout(); fig.savefig(FIG + r"\tuning.png"); plt.close(fig)  # 保存调参图
cols = ["mean radius", "mean texture"]; m2 = model(b["classifier__C"], b["classifier__solver"]).fit(Xtr[cols], ytr)  # 二维展示模型
xx, yy = np.meshgrid(np.linspace(X[cols[0]].min() - .5, X[cols[0]].max() + .5, 250), np.linspace(X[cols[1]].min() - .5, X[cols[1]].max() + .5, 250))  # 生成网格
zz = m2.predict_proba(pd.DataFrame(np.c_[xx.ravel(), yy.ravel()], columns=cols))[:, 1].reshape(xx.shape)  # 网格上的概率
fig, ax = plt.subplots(figsize=(7, 5)); ax.contourf(xx, yy, zz, 20, cmap="RdBu_r", alpha=.5); ax.contour(xx, yy, zz, [.5], colors="black"); ax.scatter(Xtr[cols[0]], Xtr[cols[1]], c=ytr, cmap="RdBu_r", s=18, alpha=.5)  # 画概率区域和训练点
wrong = m2.predict(Xte[cols]) != yte.values; ax.scatter(Xte.loc[wrong, cols[0]], Xte.loc[wrong, cols[1]], marker="X", s=100, facecolor="none", edgecolor="black", label="误分类"); ax.set_xlabel(cols[0]); ax.set_ylabel(cols[1]); ax.legend()  # 标出测试集误分类
fig.tight_layout(); fig.savefig(FIG + r"\boundary2d.png"); plt.close(fig); print("完成：figures/ 与 outputs/")  # 保存二维图并结束
