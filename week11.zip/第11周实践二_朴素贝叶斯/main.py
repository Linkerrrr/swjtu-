"""第11周实践二：西瓜数据集 3.0 朴素贝叶斯（50行精简版，桌面绝对路径）"""
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
from sklearn.model_selection import train_test_split, LeaveOneOut, StratifiedKFold, cross_val_score
from sklearn.naive_bayes import GaussianNB, CategoricalNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OrdinalEncoder
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report

BASE = Path(r"C:\Users\Lenovo\Desktop\第11周实践二_朴素贝叶斯"); FIG = BASE / "figures"; OUT = BASE / "outputs"; FIG.mkdir(parents=True, exist_ok=True); OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]; plt.rcParams["axes.unicode_minus"] = False; SEED = 42
DISCRETE = ["色泽", "根蒂", "敲声", "纹理", "脐部", "触感"]; FEATURES = ["密度", "含糖率"]; ALL = DISCRETE + FEATURES

def check(df):
    if len(df) == 0 or any(c not in df.columns for c in ALL + ["好瓜"]): raise ValueError("数据为空或缺列")
    if df[ALL + ["好瓜"]].isna().sum().sum() > 0 or set(df["好瓜"]) != {"是", "否"}: raise ValueError("数据有缺失值或标签错误")

def model(priors=None, var_smoothing=1e-9):
    if priors is not None and (len(priors) != 2 or abs(sum(priors) - 1) > 1e-9): raise ValueError("priors 必须有两个数且和为 1")
    if var_smoothing <= 0: raise ValueError("var_smoothing 必须大于 0")
    return Pipeline([("nb", GaussianNB(priors=priors, var_smoothing=var_smoothing))])

def var(m): return getattr(m.named_steps["nb"], "sigma_", getattr(m.named_steps["nb"], "var_", None))

df = pd.read_csv(BASE / "data" / "watermelon3.csv", index_col="编号"); check(df); X, y = df[FEATURES], (df["好瓜"] == "是").astype(int)

print("数据形状/原始特征/主模型特征/类别/缺失：", df.shape, df[ALL].shape, X.shape, y.value_counts().to_dict(), int(df[ALL + ["好瓜"]].isna().sum().sum()))
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5)); axes[0].bar(["坏瓜(0)", "好瓜(1)"], y.value_counts().sort_index(), color=["#c44e52", "#4c72b0"]); axes[0].set_title("类别分布")
for k, c, m in [(0, "#c44e52", "o"), (1, "#4c72b0", "s")]: axes[1].scatter(df.loc[y == k, "密度"], df.loc[y == k, "含糖率"], c=c, marker=m, edgecolor="black", label=("坏瓜" if k == 0 else "好瓜"))
axes[1].scatter(0.697, 0.460, marker="*", s=200, c="gold", edgecolor="black", label="测1"); axes[1].set_xlabel("密度"); axes[1].set_ylabel("含糖率"); axes[1].set_title("密度—含糖率散点图"); axes[1].legend()
fig.tight_layout(); fig.savefig(FIG / "data.png"); plt.close(fig)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.3, stratify=y, random_state=SEED); print("训练/测试：", len(Xtr), len(Xte), "训练编号：", Xtr.index.tolist(), "测试编号：", Xte.index.tolist())
m = model().fit(Xtr, ytr); nb = m.named_steps["nb"]; print("theta_：\n", np.round(nb.theta_, 4)); print("sigma_：\n", np.round(var(m), 4)); print("class_prior_：", np.round(nb.class_prior_, 4))
p = m.predict_proba(Xte)[:, 1]; pred = (p >= .5).astype(int); table = pd.DataFrame({"编号": Xte.index, "真实": yte.values, "预测": pred, "P(好瓜)": np.round(p, 4)}); table.to_csv(OUT / "predictions.csv", index=False); print(table.to_string(index=False))
sample = pd.DataFrame([[0.697, 0.460]], columns=FEATURES); p1 = m.predict_proba(sample)[0, 1]; print("测1：", "好瓜" if p1 >= .5 else "坏瓜", "P(好瓜)=%.4f" % p1)
cm = confusion_matrix(yte, pred); print("测试集 准确率/F1：", round(accuracy_score(yte, pred), 4), round(f1_score(yte, pred), 4)); print(cm); print(classification_report(yte, pred, target_names=["坏瓜(0)", "好瓜(1)"], digits=3))
loo = cross_val_score(m, X, y, cv=LeaveOneOut()); skf = cross_val_score(m, X, y, cv=StratifiedKFold(5, shuffle=True, random_state=SEED)); print("留一法/5折：", round(loo.mean(), 4), round(loo.std(), 4), round(skf.mean(), 4), round(skf.std(), 4))
fig, axes = plt.subplots(1, 2, figsize=(11, 4)); axes[0].bar(["留一法", "分层5折"], [loo.mean(), skf.mean()], yerr=[loo.std(), skf.std()], capsize=5, color=["#4c72b0", "#dd8452"]); axes[0].set_ylim(0, 1.1); axes[0].set_title("两种交叉验证")
vals = np.logspace(-12, 0, 7); axes[1].semilogx(vals, [cross_val_score(model(var_smoothing=v), X, y, cv=StratifiedKFold(5, shuffle=True, random_state=SEED)).mean() for v in vals], "o-"); axes[1].set_title("var_smoothing 的影响")
fig.tight_layout(); fig.savefig(FIG / "cv.png"); plt.close(fig)
xx, yy = np.meshgrid(np.linspace(.2, .8, 250), np.linspace(.02, .48, 250)); zz = m.predict_proba(pd.DataFrame(np.c_[xx.ravel(), yy.ravel()], columns=FEATURES))[:, 1].reshape(xx.shape)
fig, ax = plt.subplots(figsize=(7, 5)); ax.contourf(xx, yy, zz, 20, cmap="RdBu_r", alpha=.5); ax.contour(xx, yy, zz, [.5], colors="black"); ax.scatter(Xtr["密度"], Xtr["含糖率"], c=ytr, cmap="RdBu_r", s=30, alpha=.6)
wrong = m.predict(Xte) != yte.values; ax.scatter(Xte.loc[wrong, "密度"], Xte.loc[wrong, "含糖率"], marker="X", s=120, facecolor="none", edgecolor="black", label="误分类"); ax.scatter(0.697, 0.460, marker="*", s=220, c="gold", edgecolor="black", label="测1"); ax.set_xlabel("密度"); ax.set_ylabel("含糖率"); ax.legend()
fig.tight_layout(); fig.savefig(FIG / "boundary.png"); plt.close(fig)
m2 = model([.5, .5]).fit(Xtr, ytr); p2 = m2.predict_proba(sample)[0, 1]; print("手动先验：测1 P(好瓜)=%.4f，预测改变 %d 个" % (p2, int((m2.predict(Xte) != pred).sum())))
rows = []
for v in [1e-12, 1e-9, 1e-6, 1e-3, .1, 1]:
    mm = model(var_smoothing=v).fit(Xtr, ytr); rows.append([v, mm.predict_proba(sample)[0, 1], accuracy_score(yte, mm.predict(Xte)), np.mean(mm.predict_log_proba(Xte)[np.arange(len(yte)), yte.values])])
print(pd.DataFrame(rows, columns=["var_smoothing", "测1_P好瓜", "测试准确率", "平均对数似然"]).round(4).to_string(index=False))
enc = OrdinalEncoder(); cat = CategoricalNB(alpha=1).fit(enc.fit_transform(df.loc[Xtr.index, DISCRETE]), ytr); cp = cat.predict(enc.transform(df.loc[Xte.index, DISCRETE])); print("CategoricalNB 准确率/混淆矩阵：", round(accuracy_score(yte, cp), 4), confusion_matrix(yte, cp).tolist())
