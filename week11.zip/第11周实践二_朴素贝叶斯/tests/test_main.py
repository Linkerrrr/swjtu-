"""实践二的 6 个基础测试。"""

import numpy as np
import pandas as pd
import pytest

from main import ALL, FEATURES, check, model, var


def get_data():
    path = r"C:\Users\Lenovo\Desktop\第11周实践二_朴素贝叶斯\data\watermelon3.csv"
    return pd.read_csv(path, index_col="编号")


def test_data_shape_and_classes():
    df = get_data()
    assert df.shape == (17, 9)
    assert df[ALL].shape == (17, 8)
    assert df[FEATURES].shape == (17, 2)
    assert df["好瓜"].value_counts().to_dict() == {"否": 9, "是": 8}
    assert int(df[ALL + ["好瓜"]].isna().sum().sum()) == 0


def test_empty_missing_and_bad_label_are_rejected():
    with pytest.raises(ValueError):
        check(pd.DataFrame())
    df = get_data().drop(columns=["密度"])
    with pytest.raises(ValueError):
        check(df)
    df = get_data()
    df.loc[df.index[0], "好瓜"] = "不确定"
    with pytest.raises(ValueError):
        check(df)


def test_invalid_prior_and_smoothing_are_rejected():
    with pytest.raises(ValueError):
        model(priors=[.7, .7])
    with pytest.raises(ValueError):
        model(var_smoothing=0)


def test_model_parameters_and_probabilities():
    df = get_data()
    X, y = df[FEATURES], (df["好瓜"] == "是").astype(int)
    m = model().fit(X, y)
    nb = m.named_steps["nb"]
    assert nb.theta_.shape == (2, 2)
    assert var(m).shape == (2, 2)
    assert np.isclose(nb.class_prior_.sum(), 1)
    prob = m.predict_proba(X)
    assert prob.shape == (17, 2)
    assert np.all((prob >= 0) & (prob <= 1))
    assert np.allclose(prob.sum(axis=1), 1)


def test_split_and_test1():
    df = get_data()
    X, y = df[FEATURES], (df["好瓜"] == "是").astype(int)
    from sklearn.model_selection import train_test_split
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=.3, stratify=y, random_state=42)
    m = model().fit(Xtr, ytr)
    sample = pd.DataFrame([[0.697, 0.460]], columns=FEATURES)
    prob = m.predict_proba(sample)[0]
    assert len(Xte) == 6
    assert 0 <= prob[1] <= 1
    assert len(m.predict(Xte)) == 6


def test_categorical_nb_runs():
    from sklearn.naive_bayes import CategoricalNB
    from sklearn.preprocessing import OrdinalEncoder
    df = get_data()
    y = (df["好瓜"] == "是").astype(int)
    Xd = OrdinalEncoder().fit_transform(df[[c for c in ALL if c not in FEATURES]])
    m = CategoricalNB(alpha=1).fit(Xd, y)
    assert len(m.predict(Xd)) == 17
