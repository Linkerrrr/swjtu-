# 第 11 周实践二：西瓜数据集 3.0 朴素贝叶斯

一个精简的课程实践项目：只用一个 `main.py` 完成 GaussianNB 训练、评估、
决策边界、先验与 `var_smoothing` 分析、两种交叉验证和选做的 CategoricalNB。
所有随机过程固定 `random_state=42`。

## 数据集

唯一数据集：西瓜数据集 3.0，文件为 `data/watermelon3.csv`。

- 17 个样本，8 个特征（6 个离散 + 2 个连续）
- 坏瓜（0）9 条，好瓜（1）8 条
- 无缺失值
- 主模型只使用“密度”和“含糖率”两个连续特征

## 运行

```bash
python -m pip install -r requirements.txt
python main.py
pytest
```

`main.py` 会自动创建 `figures/` 和 `outputs/`。

## 代码步骤

| 步骤 | 做法 |
|---|---|
| 读取 | 读 CSV，检查缺列、缺失值和标签 |
| 探索 | 画类别分布和密度—含糖率散点图 |
| 划分 | 7:3 分层划分，训练 11 / 测试 6 |
| 模型 | Pipeline 封装 GaussianNB |
| 参数 | 输出 `theta_`、`sigma_`、`class_prior_` |
| 评估 | 准确率、F1、混淆矩阵、留一法、分层 5 折 |
| 画图 | 数据图、决策边界、交叉验证图 |
| 分析 | `priors=[0.5,0.5]`、`var_smoothing` 曲线 |
| 选做 | 6 个离散特征 + `CategoricalNB` |

## 主要结果

- 测试集：准确率 `0.5000`（3/6），F1 `0.4000`
- 留一法：`0.6471 ± 0.4779`
- 分层 5 折：`0.6333 ± 0.2211`
- 测1：预测好瓜，`P(好瓜)=0.9996`
- CategoricalNB 测试准确率：`0.5000`

测试集只有 6 条，错 1 条就会变化 16.7 个百分点，所以同时报告留一法和 5 折结果。

## 文件

```text
main.py                全部代码
README.md              本文件
requirements.txt       依赖
data/watermelon3.csv   西瓜数据集 3.0
figures/               data.png / boundary.png / cv.png
outputs/               predictions.csv
tests/test_main.py     6 个基础测试
```
