"""knn.py 的单元测试。

运行方式（任意目录）：
    python tests/test_knn.py
或：
    python -m unittest discover -s tests
"""

import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))  # 找到 src/knn.py
from knn import (  # noqa: E402
    KNNClassifier,
    euclidean_distance,
    get_k_neighbors,
    majority_vote,
    manhattan_distance,
)


class TestDistance(unittest.TestCase):
    def test_euclidean_single_point(self):
        """3-4-5 直角三角形，手算应为 5。"""
        self.assertAlmostEqual(euclidean_distance(np.array([0.0, 0.0]), np.array([3.0, 4.0])), 5.0)

    def test_euclidean_batch(self):
        """单点对一批样本，应返回每个样本的距离。"""
        point = np.array([0.0, 0.0])
        batch = np.array([[3.0, 4.0], [0.0, 0.0], [1.0, 0.0]])
        np.testing.assert_allclose(euclidean_distance(point, batch), [5.0, 0.0, 1.0])

    def test_euclidean_matrix(self):
        """两批样本之间应得到 (n, m) 距离矩阵，且元素与逐点计算一致。"""
        A = np.array([[0.0, 0.0], [1.0, 1.0]])
        B = np.array([[3.0, 4.0], [0.0, 0.0], [1.0, 0.0]])
        D = euclidean_distance(A, B)
        self.assertEqual(D.shape, (2, 3))
        for i in range(A.shape[0]):
            for j in range(B.shape[0]):
                self.assertAlmostEqual(D[i, j], euclidean_distance(A[i], B[j]))

    def test_manhattan(self):
        """(1,2) 到 (4,6) 的曼哈顿距离 = |3|+|4| = 7。"""
        self.assertAlmostEqual(manhattan_distance(np.array([1.0, 2.0]), np.array([4.0, 6.0])), 7.0)

    def test_manhattan_batch(self):
        point = np.array([1.0, 2.0])
        batch = np.array([[4.0, 6.0], [1.0, 2.0]])
        np.testing.assert_allclose(manhattan_distance(point, batch), [7.0, 0.0])


class TestNeighbors(unittest.TestCase):
    def test_get_k_neighbors_order(self):
        """距离 [5, 1.2, 3.5, 0.5, 4] 中最近的 3 个下标应为 3、1、2。"""
        distances = np.array([5.0, 1.2, 3.5, 0.5, 4.0])
        self.assertEqual(get_k_neighbors(distances, 3).tolist(), [3, 1, 2])

    def test_get_k_neighbors_illegal_k(self):
        """k 超过样本数、k 小于 1 都要报错。"""
        with self.assertRaises(ValueError):
            get_k_neighbors(np.array([1.0, 2.0]), 5)
        with self.assertRaises(ValueError):
            get_k_neighbors(np.array([1.0, 2.0]), 0)


class TestVote(unittest.TestCase):
    def test_majority_vote(self):
        """2 票对 1 票，多的赢。"""
        self.assertEqual(majority_vote([0, 0, 1]), 0)

    def test_majority_vote_tie_picks_nearest(self):
        """票数相同（1:1）时选距离更近的那个类别。"""
        self.assertEqual(majority_vote([1, 0], distances=[0.1, 2.0]), 1)
        self.assertEqual(majority_vote([0, 1], distances=[2.0, 0.1]), 1)


class TestClassifier(unittest.TestCase):
    def setUp(self):
        # 两团分得很开的点：类别 0 在 0 附近，类别 1 在 10 附近
        self.X = np.array([[0.0, 0.0], [0.1, 0.1], [10.0, 10.0], [10.1, 10.1]])
        self.y = np.array([0, 0, 1, 1])

    def test_fit_predict(self):
        clf = KNNClassifier(k=1).fit(self.X, self.y)
        np.testing.assert_array_equal(clf.predict(np.array([[0.05, 0.05], [10.05, 9.95]])), [0, 1])

    def test_predict_before_fit(self):
        with self.assertRaises(RuntimeError):
            KNNClassifier(k=1).predict(np.array([[0.0, 0.0]]))

    def test_k_too_large(self):
        with self.assertRaises(ValueError):
            KNNClassifier(k=10).fit(self.X, self.y)

    def test_dimension_mismatch(self):
        clf = KNNClassifier(k=1).fit(self.X, self.y)
        with self.assertRaises(ValueError):
            clf.predict(np.array([[0.0, 0.0, 0.0]]))

    def test_metric_switch(self):
        """曼哈顿度量也要能跑，且在这组数据上结果一致。"""
        clf = KNNClassifier(k=1, metric="manhattan").fit(self.X, self.y)
        np.testing.assert_array_equal(clf.predict(np.array([[0.05, 0.05]])), [0])


class TestWithIrisData(unittest.TestCase):
    def test_iris_accuracy(self):
        """真实数据冒烟测试：用 k=3 在训练集上拟合，测试集准确率应高于 90%。"""
        import pandas as pd

        data = Path(__file__).resolve().parents[1] / "data" / "iris_dataset.csv"
        if not data.exists():
            self.skipTest(f"数据文件不存在：{data}")

        df = pd.read_csv(data, encoding="utf-8-sig")
        cols = ["sepal length (cm)", "sepal width (cm)", "petal length (cm)", "petal width (cm)"]
        X = df[cols].values.astype(float)
        y = df["target_name"].map({"setosa": 0, "versicolor": 1, "virginica": 2}).values

        rng = np.random.default_rng(42)
        idx = rng.permutation(len(X))
        cut = int(len(X) * 0.8)
        tr, te = idx[:cut], idx[cut:]

        mu, sd = X[tr].mean(0), X[tr].std(0)
        clf = KNNClassifier(k=3).fit((X[tr] - mu) / sd, y[tr])
        acc = float(np.mean(clf.predict((X[te] - mu) / sd) == y[te]))
        self.assertGreater(acc, 0.90, f"准确率过低：{acc:.2%}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
