"""KNN 核心算法：欧氏距离、曼哈顿距离、最近邻搜索、多数投票、分类器。

本文件只放算法，不读数据、不画图、不打印；数据流程在 main.py 里。
"""

import numpy as np


def _pairwise(x1, x2):
    """把两个输入整理成可广播的形状，供两个距离函数复用。

    单点 vs 单点   (d,)   - (d,)    -> (d,)
    单点 vs 一批   (d,)   - (m,d)   -> (m,d)
    一批 vs 一批   (n,d)  - (m,d)   -> (n,m,d)
    """
    a = np.asarray(x1, dtype=float)
    b = np.asarray(x2, dtype=float)
    if a.ndim == 2 and b.ndim == 2:  # 两批样本：各自升一维再相减
        a, b = a[:, None, :], b[None, :, :]
    return a - b


def euclidean_distance(x1, x2):
    """欧氏距离（直线距离）。

    支持三种用法：
        单点 vs 单点      (d,) vs (d,)   -> 标量
        单点 vs 一批      (d,) vs (m, d) -> (m,)
        一批 vs 一批      (n,d) vs (m,d) -> (n, m)
    """
    return np.sqrt(np.sum(_pairwise(x1, x2) ** 2, axis=-1))


def manhattan_distance(x1, x2):
    """曼哈顿距离（沿格子走的距离），用法与 euclidean_distance 相同。"""
    return np.sum(np.abs(_pairwise(x1, x2)), axis=-1)


def get_k_neighbors(distance, k):
    """从一维距离数组中找出最近的 k 个邻居，返回下标（按距离从近到远）。"""
    distance = np.asarray(distance, dtype=float).ravel()
    if k < 1:
        raise ValueError(f"k 必须是正整数，当前 k={k}")
    if k > distance.size:
        raise ValueError(f"k={k} 超过可用样本数 {distance.size}")
    return np.argsort(distance, kind="stable")[:k]  # stable：距离相同时保持原顺序


def majority_vote(labels, distances=None):
    """多数投票；票数相同时，选距离更近的那个类别（保证结果唯一、可复现）。"""
    labels = list(labels)
    if not labels:
        raise ValueError("邻居为空，无法投票")
    if distances is None:
        distances = np.arange(len(labels), dtype=float)

    counts, nearest = {}, {}
    for label, dist in zip(labels, distances):
        counts[label] = counts.get(label, 0) + 1
        nearest[label] = min(nearest.get(label, np.inf), dist)

    # 先比票数，再比该类中最近的距离（距离小的优先）
    return max(counts, key=lambda label: (counts[label], -nearest[label]))


class KNNClassifier:
    """KNN 分类器：fit 记住训练集，predict 对每个样本找 k 个邻居投票。

    k        近邻个数
    metric   距离度量，"euclidean"（默认）或 "manhattan"
    """

    def __init__(self, k=3, metric="euclidean"):
        if k < 1:
            raise ValueError(f"k 必须是正整数，当前 k={k}")
        if metric not in ("euclidean", "manhattan"):
            raise ValueError(f"不支持的距离度量：{metric}")
        self.k = k
        self.metric = metric

    def _distance(self, x, X):
        if self.metric == "manhattan":
            return manhattan_distance(x, X)
        return euclidean_distance(x, X)

    def fit(self, X_train, y_train):
        """记住训练数据（KNN 不需要真正的训练过程）。"""
        X_train = np.asarray(X_train, dtype=float)
        y_train = np.asarray(y_train)
        if X_train.ndim != 2:
            raise ValueError(f"X_train 必须是二维数组，当前维度 {X_train.ndim}")
        if len(X_train) != len(y_train):
            raise ValueError(f"特征 {len(X_train)} 行与标签 {len(y_train)} 个不一致")
        if self.k > len(X_train):
            raise ValueError(f"k={self.k} 超过训练样本数 {len(X_train)}")
        self.X_train, self.y_train = X_train, y_train
        return self

    def _predict_single(self, x):
        distance = self._distance(x, self.X_train)  # 该样本到所有训练样本的距离
        k_indices = get_k_neighbors(distance, self.k)  # 最近的 k 个邻居下标
        k_labels = self.y_train[k_indices]  # 这些邻居的类别
        return majority_vote(k_labels, distance[k_indices])

    def predict(self, X_test):
        """对测试集逐样本预测，返回预测标签数组。"""
        if not hasattr(self, "X_train"):
            raise RuntimeError("请先调用 fit() 再 predict()")
        X_test = np.asarray(X_test, dtype=float)
        if X_test.ndim == 1:
            X_test = X_test.reshape(1, -1)
        if X_test.shape[1] != self.X_train.shape[1]:
            raise ValueError(
                f"特征维度不一致：训练 {self.X_train.shape[1]} 维，测试 {X_test.shape[1]} 维"
            )
        return np.array([self._predict_single(x) for x in X_test])

    def predict_vectorized(self, X_test):
        """向量化版本：一次算出「所有测试样本 × 所有训练样本」的距离矩阵，再按行取邻居。

        结果与 predict() 相同，区别是把最耗时的距离计算交给 NumPy，避免 Python 逐样本循环。
        """
        if not hasattr(self, "X_train"):
            raise RuntimeError("请先调用 fit() 再 predict()")
        X_test = np.asarray(X_test, dtype=float)
        if X_test.ndim == 1:
            X_test = X_test.reshape(1, -1)
        if X_test.shape[1] != self.X_train.shape[1]:
            raise ValueError(
                f"特征维度不一致：训练 {self.X_train.shape[1]} 维，测试 {X_test.shape[1]} 维"
            )

        dist = self._distance(X_test, self.X_train)  # (n_test, n_train) 距离矩阵
        idx = np.argsort(dist, axis=1, kind="stable")[:, : self.k]  # 每行最近的 k 个邻居下标
        return np.array([majority_vote(self.y_train[i], row[i]) for row, i in zip(dist, idx)])
