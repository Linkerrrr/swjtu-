"""Iris 鸢尾花 KNN 分类实验入口。

流程：读取数据 → 数据探索 → 划分训练/测试 → Z-score 标准化
      → 5 折交叉验证选 k → 测试集评估（准确率/混淆矩阵/分类报告）→ 画图。

运行（任意目录都可以）：
    python src/main.py
"""

import random
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))  # 保证能找到同目录的 knn.py
from knn import KNNClassifier, get_k_neighbors  # noqa: E402

# ---------- 路径与全局配置 ----------
BASE_DIR = Path(__file__).resolve().parents[1]  # knn_homework/
DATA_PATH = BASE_DIR / "data" / "iris_dataset.csv"
FIG_DIR = BASE_DIR / "figures"

SEED = 42  # 全局唯一的随机种子：划分、交叉验证都用它，保证结果可复现
TEST_RATIO = 0.2  # 测试集比例
K_LIST = list(range(1, 21))  # 候选 k：1~20
N_FOLDS = 5  # 交叉验证折数

FEATURE_COLS = [
    "sepal length (cm)",
    "sepal width (cm)",
    "petal length (cm)",
    "petal width (cm)",
]
LABEL_MAP = {"setosa": 0, "versicolor": 1, "virginica": 2}
CLASS_NAMES = list(LABEL_MAP.keys())


def set_seed(seed=SEED):
    """统一随机种子：numpy 与 random 都用同一个值。"""
    np.random.seed(seed)
    random.seed(seed)


# ---------- 1. 读取与探索 ----------
def load_data(path=DATA_PATH):
    """读取 CSV（用 utf-8-sig 兼容带 BOM 的文件）。"""
    print("--开始读取数据--")
    if not Path(path).exists():
        raise FileNotFoundError(f"找不到数据文件：{path}")
    df = pd.read_csv(path, encoding="utf-8-sig")
    print(f"数据文件：{Path(path).name}")
    return df


def explore_data(df):
    """输出样本数、特征数、类别分布、缺失值情况（作业第 2 条要求）。"""
    print("\n--数据探索--")
    print(f"样本数：{df.shape[0]}")
    print(f"特征数：{len(FEATURE_COLS)}，列名：{FEATURE_COLS}")
    print("类别分布：")
    for name, cnt in df["target_name"].value_counts().items():
        print(f"  {name}: {cnt} 条")
    missing = df.isna().sum()
    print(f"缺失值总数：{int(missing.sum())}")
    return df


def build_xy(df):
    """拆出特征矩阵 X 和数字标签 y（字符串标签映射成 0/1/2，方便混淆矩阵和画图）。"""
    X = df[FEATURE_COLS].values.astype(float)
    y_name = df["target_name"].values
    y = np.array([LABEL_MAP[name] for name in y_name])
    print(f"\n特征矩阵 X 形状：{X.shape}，标签 y 形状：{y.shape}")
    print(f"类别编号：{np.unique(y)}")
    return X, y


# ---------- 2. 划分与标准化 ----------
def split_data(X, y, test_ratio=TEST_RATIO, seed=SEED):
    """按类别分层抽样，8:2 划分训练集/测试集（种子固定，划分可复现）。

    为什么分层：直接打乱有可能把某一类抽得太少（比如测试集只分到 6 条 versicolor），
    准确率波动会很大。分层保证测试集里三类比例与整体一致（各 10 条）。
    """
    rng = np.random.default_rng(seed)
    train_idx, test_idx = [], []
    for label in np.unique(y):
        cls_idx = rng.permutation(np.flatnonzero(y == label))  # 该类的样本索引，打乱
        cut = int(round(len(cls_idx) * (1 - test_ratio)))
        train_idx.extend(cls_idx[:cut].tolist())
        test_idx.extend(cls_idx[cut:].tolist())

    train_idx = rng.permutation(np.array(train_idx))  # 再整体打乱顺序
    test_idx = rng.permutation(np.array(test_idx))

    X_train, X_test = X[train_idx], X[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]

    print("\n--划分数据集--")
    print(f"训练集：{X_train.shape}，测试集：{X_test.shape}")
    for name, label in LABEL_MAP.items():
        print(f"  {name}: 训练 {int((y_train == label).sum())} 条 / 测试 {int((y_test == label).sum())} 条")
    return X_train, X_test, y_train, y_test


def standardize(X_train, X_test):
    """Z-score 标准化：均值和标准差只用训练集算，避免测试集信息泄漏。"""
    mean_train = np.mean(X_train, axis=0)
    std_train = np.std(X_train, axis=0)
    std_train[std_train == 0] = 1.0  # 防止某个特征方差为 0 时除零

    X_train_scaled = (X_train - mean_train) / std_train
    X_test_scaled = (X_test - mean_train) / std_train

    print("\n--Z-score 标准化（仅用训练集统计量）--")
    print("训练集特征均值（应接近 0）：", np.round(X_train_scaled.mean(axis=0), 4))
    print("训练集特征标准差（应接近 1）：", np.round(X_train_scaled.std(axis=0), 4))
    return X_train_scaled, X_test_scaled


# ---------- 3. 交叉验证选 k ----------
def cross_validate_k(X, y, k_list=K_LIST, n_folds=N_FOLDS, seed=SEED):
    """在训练集上做 n 折交叉验证，返回 {k: 平均准确率}。"""
    rng = np.random.default_rng(seed)
    folds = np.array_split(rng.permutation(len(X)), n_folds)
    fold_sets = [(np.setdiff1d(np.arange(len(X)), va), va) for va in folds]

    scores = {}
    for k in k_list:
        accs = []
        for tr, va in fold_sets:
            clf = KNNClassifier(k=k).fit(X[tr], y[tr])
            accs.append(float(np.mean(clf.predict(X[va]) == y[va])))
        scores[k] = float(np.mean(accs))
    return scores


# ---------- 4. 近邻搜索演示 ----------
def show_neighbors(clf, x, k, true_label=None, class_names=CLASS_NAMES):
    """打印一个样本的 k 个最近邻：下标、距离、类别（距离在标准化后的空间里算）。"""
    dist = clf._distance(x, clf.X_train)
    idx = get_k_neighbors(dist, k)
    print(f"\n--近邻搜索示例（第 1 个测试样本，k={k}）--")
    print(f"  {'邻居下标':<10}{'距离':>10}  类别")
    for i in idx:
        print(f"  {int(i):<10}{dist[i]:>10.4f}  {class_names[clf.y_train[i]]}")

    pred = clf._predict_single(x)
    print(f"  投票结果：{class_names[pred]}"
          + (f"，真实类别：{class_names[true_label]}（{'预测正确' if pred == true_label else '预测错误'}）"
             if true_label is not None else ""))


# ---------- 5. 评估 ----------
def confusion_matrix(y_true, y_pred, n_classes=3):
    """手写混淆矩阵：行=真实类别，列=预测类别。"""
    cm = np.zeros((n_classes, n_classes), dtype=int)
    for t, p in zip(y_true, y_pred):
        cm[t, p] += 1
    return cm


def classification_report(y_true, y_pred, class_names=CLASS_NAMES):
    """手写简版分类报告：每类精确率/召回率/F1 与宏平均。"""
    cm = confusion_matrix(y_true, y_pred, len(class_names))
    rows, lines = [], []
    for i, name in enumerate(class_names):
        tp = cm[i, i]
        precision = tp / cm[:, i].sum() if cm[:, i].sum() else 0.0
        recall = tp / cm[i, :].sum() if cm[i, :].sum() else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        rows.append((precision, recall, f1))
        lines.append(f"  {name:<11} 精确率={precision:.3f}  召回率={recall:.3f}  F1={f1:.3f}")

    macro = np.mean(rows, axis=0)
    lines.append(f"  {'宏平均':<10} 精确率={macro[0]:.3f}  召回率={macro[1]:.3f}  F1={macro[2]:.3f}")
    return "\n".join(lines)


def evaluate(y_true, y_pred):
    """输出准确率、混淆矩阵、分类报告。"""
    acc = float(np.mean(y_true == y_pred))
    cm = confusion_matrix(y_true, y_pred)
    print(f"\n--测试集评估--")
    print(f"准确率：{acc:.2%}（{int((y_true == y_pred).sum())}/{len(y_true)}）")
    print("混淆矩阵（行=真实，列=预测）：")
    print(cm)
    print("分类报告：")
    print(classification_report(y_true, y_pred))
    return acc, cm


# ---------- 6. 性能对比 ----------
def benchmark_predict(X_train, y_train, X_test, k, n_repeat=20, scale=20):
    """对比「逐样本循环版」与「向量化版」的预测耗时。

    鸢尾花只有 30 条测试样本，单次计时会被函数调用开销淹没，
    所以除了原始规模，还把测试集复制 scale 倍再测一次，看数据变大后的差距。
    """
    print("\n--性能对比：循环版 vs 向量化版--")
    clf = KNNClassifier(k=k).fit(X_train, y_train)

    for tag, Xq in (("原始测试集", X_test), (f"放大 {scale} 倍", np.tile(X_test, (scale, 1)))):
        clf.predict(Xq[:2])  # 预热，避免第一次调用把导入开销算进去
        clf.predict_vectorized(Xq[:2])

        t0 = time.perf_counter()
        for _ in range(n_repeat):
            pred_loop = clf.predict(Xq)
        t_loop = (time.perf_counter() - t0) / n_repeat

        t0 = time.perf_counter()
        for _ in range(n_repeat):
            pred_vec = clf.predict_vectorized(Xq)
        t_vec = (time.perf_counter() - t0) / n_repeat

        same = bool(np.array_equal(pred_loop, pred_vec))
        speedup = t_loop / t_vec if t_vec else float("inf")
        print(f"  {tag}（{len(Xq)} 条）：循环 {t_loop * 1000:7.2f} ms/次  "
              f"向量化 {t_vec * 1000:7.2f} ms/次  加速 {speedup:.2f} 倍  结果一致：{same}")


# ---------- 7. 画图（matplotlib 用到时才导入） ----------
def _plt():
    import matplotlib

    matplotlib.use("Agg")  # 不弹窗，直接存文件
    import matplotlib.pyplot as plt

    # 让图里的中文正常显示（Windows 自带微软雅黑/黑体；换系统时自动退回其它字体）
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False  # 负号正常显示
    return plt


def plot_k_curve(scores, best_k, path=None):
    """k 值与交叉验证准确率曲线。"""
    from matplotlib import ticker as mticker

    plt = _plt()
    ks, accs = list(scores.keys()), list(scores.values())
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(ks, accs, marker="o", linestyle="-", color="#1f77b4", label="5 折交叉验证准确率")
    ax.scatter([best_k], [scores[best_k]], s=140, facecolors="none",
               edgecolors="crimson", linewidths=2, label=f"最优 k={best_k}")
    ax.set_title("KNN: k 值与交叉验证准确率")
    ax.set_xlabel("近邻数 k")
    ax.set_ylabel("交叉验证准确率")
    ax.set_xticks(ks)
    ax.set_ylim(0.85, 1.0)  # 从 85% 起画，避免只看 0.90~0.94 的窄区间夸大差异
    ax.yaxis.set_major_formatter(mticker.PercentFormatter(1.0, decimals=0))
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    if path:
        fig.savefig(path, dpi=150)
        print(f"已保存图：{path}")
    plt.close(fig)


def plot_confusion(cm, path=None):
    """混淆矩阵热力图。"""
    plt = _plt()
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    im = ax.imshow(cm, cmap="Blues")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            color = "white" if cm[i, j] > cm.max() / 2 else "black"
            ax.text(j, i, cm[i, j], ha="center", va="center", color=color, fontsize=13)
    ax.set_xticks(range(3), CLASS_NAMES)
    ax.set_yticks(range(3), CLASS_NAMES)
    ax.set_xlabel("预测类别")
    ax.set_ylabel("真实类别")
    ax.set_title("测试集混淆矩阵")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    if path:
        fig.savefig(path, dpi=150)
        print(f"已保存图：{path}")
    plt.close(fig)


def plot_decision_boundary(X_train_2d, y_train, X_test_2d, y_test, k, path=None):
    """用两个花瓣特征画决策边界：底色是分类区域，点用训练集，✕ 标出测试集里分错的样本。"""
    plt = _plt()
    clf = KNNClassifier(k=k).fit(X_train_2d, y_train)

    x_min, x_max = X_train_2d[:, 0].min() - 0.5, X_train_2d[:, 0].max() + 0.5
    y_min, y_max = X_train_2d[:, 1].min() - 0.5, X_train_2d[:, 1].max() + 0.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200), np.linspace(y_min, y_max, 200))
    grid = np.c_[xx.ravel(), yy.ravel()]
    zz = clf.predict(grid).reshape(xx.shape)

    colors = ["#4C72B0", "#DD8452", "#55A868"]
    fig, ax = plt.subplots(figsize=(7, 5.5))
    ax.contourf(xx, yy, zz, alpha=0.25, levels=[-0.5, 0.5, 1.5, 2.5], colors=colors)
    for label, name, c in zip(range(3), CLASS_NAMES, colors):
        mask = y_train == label
        ax.scatter(X_train_2d[mask, 0], X_train_2d[mask, 1], s=28, color=c,
                   edgecolor="k", linewidth=0.4, label=name)

    # 标出测试集里被这两个特征判错的样本
    wrong = clf.predict(X_test_2d) != y_test
    ax.scatter(X_test_2d[wrong, 0], X_test_2d[wrong, 1], s=170, marker="x",
               color="crimson", linewidths=2.2, zorder=5,
               label=f"误分类样本（{int(wrong.sum())} 个）")

    ax.set_title(f"决策边界（k={k}，花瓣长度 vs 花瓣宽度，二维子集）")
    ax.set_xlabel("花瓣长度（标准化）")
    ax.set_ylabel("花瓣宽度（标准化）")
    ax.legend()
    fig.tight_layout()
    if path:
        fig.savefig(path, dpi=150)
        print(f"已保存图：{path}（二维子集上误分类 {int(wrong.sum())} 个）")
    plt.close(fig)


# ---------- 6. 与 sklearn 对照（可选） ----------
def compare_with_sklearn(X_train, y_train, X_test, y_test, k):
    """用 sklearn 的 KNeighborsClassifier 对照，比较准确率与预测差异。"""
    try:
        from sklearn.neighbors import KNeighborsClassifier
    except ImportError:
        print("\n[跳过] 未安装 scikit-learn，无法做对照实验（pip install scikit-learn 后可运行）")
        return None

    ours = KNNClassifier(k=k).fit(X_train, y_train).predict(X_test)
    theirs = KNeighborsClassifier(n_neighbors=k).fit(X_train, y_train).predict(X_test)

    acc_ours = float(np.mean(ours == y_test))
    acc_sklearn = float(np.mean(theirs == y_test))
    diff = int(np.sum(ours != theirs))
    print("\n--与 sklearn 对照--")
    print(f"手写实现准确率：{acc_ours:.2%}")
    print(f"sklearn 准确率：{acc_sklearn:.2%}")
    print(f"两者预测不同的样本数：{diff}")
    if diff:
        print("（差异通常来自平票处理规则、距离相同时的排序方式不同）")
    return acc_ours, acc_sklearn, diff


# ---------- 主流程 ----------
def main():
    set_seed(SEED)  # 统一随机种子

    df = load_data()  # 1. 读取
    explore_data(df)  # 2. 探索
    X, y = build_xy(df)  # 3. 特征与标签

    X_train, X_test, y_train, y_test = split_data(X, y)  # 4. 划分
    X_train_s, X_test_s = standardize(X_train, X_test)  # 5. 标准化

    scores = cross_validate_k(X_train_s, y_train)  # 6. 交叉验证
    best_k = max(scores, key=lambda k: (round(scores[k], 6), -k))  # 同分取较小的 k
    print("\n--交叉验证结果--")
    for k, acc in scores.items():
        print(f"  k={k:>2}  平均准确率={acc:.4f}")
    print(f"最优 k={best_k}，交叉验证准确率={scores[best_k]:.2%}")

    clf = KNNClassifier(k=best_k).fit(X_train_s, y_train)  # 7. 用最优 k 训练
    show_neighbors(clf, X_test_s[0], best_k, y_test[0])  # 8. 近邻搜索示例
    y_pred = clf.predict(X_test_s)
    acc, cm = evaluate(y_test, y_pred)  # 9. 评估

    try:  # 10. 画图（需要 matplotlib）
        FIG_DIR.mkdir(exist_ok=True)
        plot_k_curve(scores, best_k, FIG_DIR / "k_curve.png")
        plot_confusion(cm, FIG_DIR / "confusion_matrix.png")
        plot_decision_boundary(
            X_train_s[:, 2:4], y_train, X_test_s[:, 2:4], y_test, best_k,
            FIG_DIR / "decision_boundary.png",
        )
    except ImportError:
        print("\n[跳过] 未安装 matplotlib，无法生成图片（pip install matplotlib 后可运行）")

    benchmark_predict(X_train_s, y_train, X_test_s, best_k)  # 11. 性能对比

    compare_with_sklearn(X_train_s, y_train, X_test_s, y_test, best_k)  # 12. 对照

    print(f"\n== 完成：最优 k={best_k}，测试集准确率={acc:.2%} ==")


if __name__ == "__main__":
    main()
